import Navbar from './components/Navbar';
import Hero from './components/Hero';
import TweetLove from './components/TweetLove';
import Proof from "./components/Proof";
import Cohorts from './components/Cohorts';
import Testimonials from './components/Testimonials';
import UdemySection from './components/UdemySection';
import Features from './components/Features';
import ButWhyChaiCode from './components/ButWhyChaiCode';
import TopicsCloud from './components/TopicsCloud';
import Footer from './components/Footer';

function App() {
  return (
    <div className="bg-white dark:bg-darkBg text-gray-900 dark:text-white min-h-screen font-sans">
      <Navbar />
      <main>
        <Hero />
        <TweetLove />
        <Proof />
        <Cohorts />
        <Testimonials />
        <UdemySection />
        <Features />
        <ButWhyChaiCode />
        <TopicsCloud />
       
      </main>
      <Footer />
    </div>
  );
}

export default App;
