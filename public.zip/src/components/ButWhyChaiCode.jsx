import React from 'react';

const features = [
  { title: 'Comprehensive Curriculum', desc: 'Wean key concepts and hands-on skills with clarity and confidence. Learn what matters, the right way, thoroughly, practically, and easy to understand.' },
  { title: 'You finish it', desc: 'Our cohort style is collaborative, putting students from together, stay motivated, and complete the course on time as a community.' },
  { title: 'Industry Guests', desc: 'We’re connected with industry players and regularly bring them to your classes for organic, fun, and insightful sessions with questions.' },
  { title: 'Code and Chill', desc: 'Coding should be fun, not frightening. It’s fun, feel super chill, but with time and practice everything starts to click and fall into place.' },
  { title: 'Improve Communication', desc: 'One of the best ways to boost communication skills is through practice. Our peer classes make it happen where co-learners teach, share, and grow together.' },
  { title: 'Bounties', desc: 'Every cohort comes with exciting cash prizes and some even feature a MacBook giveaway! It’s our way of keeping the motivation high and the learning fun.' }
];

export default function WhyChaiCodeSection() {
  return (
    <section className="max-w-6xl mx-auto px-4 py-16">
      <h2 className="text-4xl font-bold text-center mb-2">But Why ChaiCode ?</h2>
      <p className="text-center mb-12">ChaiCode exists because we love tech and teaching</p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
        <div className="space-y-4">
          {features.slice(0, 3).map((f, i) => (
            <div key={i} className="border rounded-xl p-4 shadow-sm">
              <h3 className="font-semibold mb-1">{f.title}</h3>
              <p className="text-sm text-gray-700">{f.desc}</p>
            </div>
          ))}
        </div>

        <div className="flex flex-col items-center border rounded-xl p-6 shadow-md">
          <img 
            src="https://via.placeholder.com/200x150" 
            alt="Hitesh Choudhary" 
            className="rounded-lg mb-4"
          />
          <div className="text-center">
            <h3 className="text-xl font-bold">Hitesh Choudhary</h3>
            <p className="text-sm text-gray-600 mb-2">
              Retired from corporate and full-time YouTuber, x founder of LCO (acquired), x CTO, Sr. Director at PW.
              2 YT channels (956k & 476k), stepped into 43 countries.
            </p>
            <h4 className="font-semibold">Approach</h4>
            <p className="text-sm text-gray-700">
              Project based courses with peer learning and buddies with many activities
            </p>
          </div>
          <div className="flex justify-center mt-4 space-x-2">
            {[1, 2, 3].map(i => (
              <div key={i} className="w-4 h-4 rounded bg-gray-300"></div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          {features.slice(3).map((f, i) => (
            <div key={i} className="border rounded-xl p-4 shadow-sm">
              <h3 className="font-semibold mb-1">{f.title}</h3>
              <p className="text-sm text-gray-700">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="text-center mt-8">
        <button className="px-6 py-2 bg-white text-black border border-gray-400 rounded shadow-sm hover:bg-gray-100">
          Join Cohorts Live Classes
        </button>
      </div>
    </section>
  );
}
