import React from 'react';

const cohortsData = [
  {
    title: 'Web Dev Cohort – Live 1.0',
    description: 'Learn to build software for web with best and latest tech stack.',
    price: '6,999 INR',
    ytEmbed: 'https://www.youtube.com/embed/dQw4w9WgXcQ' // Replace with real video
  },
  {
    title: 'DSA Mastery Cohort – Live 1.0',
    description: 'Master DSA with problem solving and mock interviews.',
    price: '4,999 INR',
    ytEmbed: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    title: 'Frontend Pro Cohort – Live 1.0',
    description: 'Deep dive into React, Tailwind, and advanced frontend practices.',
    price: '5,499 INR',
    ytEmbed: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  }
];

const Cohorts = () => {
  return (
    <section className="py-20 bg-white dark:bg-darkBg" id="cohorts">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white">Cohorts</h2>
          <p className="text-xl text-gray-600 dark:text-gray-300">Live training classes</p>
        </div>

        <div className="grid gap-10 md:grid-cols-3 sm:grid-cols-2 grid-cols-1">
          {cohortsData.map((cohort, index) => (
            <div key={index} className="border border-gray-300 dark:border-gray-700 rounded-lg shadow-md p-5 bg-white dark:bg-gray-900 transition">
              <div className="w-full h-64 mb-4">
                <iframe
                  className="w-full h-full rounded-md"
                  src={cohort.ytEmbed}
                  title={`Cohort video ${index}`}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{cohort.title}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">{cohort.description}</p>
              <div className="mt-4 flex justify-between items-center">
                <span className="font-semibold text-primary">{cohort.price}</span>
                <button className="bg-amber-600 hover:bg-amber-700 text-white text-sm px-4 py-2 rounded">
                  Buy Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Cohorts;
