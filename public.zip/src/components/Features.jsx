import React from 'react';

const features = [
  {
    title: 'Taught by Professionals',
    description: 'Our cohorts are being taught by top industry experts and educators.'
  },
  {
    title: 'Bounties',
    description: 'Earn rewards, from Cash to MacBook. Keeps you motivated to work hard.'
  },
  {
    title: 'Coding hostels',
    description: 'There is nothing like late night discussion with fellow learners and solving bugs.'
  },
  {
    title: 'Peer Code Reviews',
    description: 'With our internal tools like Masterji, every code assignment gets feedback to improve your code.'
  },
  {
    title: 'Leet Lab',
    description: 'Our in-house built LeetCode style platform that helps you to understand foundation of programming language.'
  },
  {
    title: 'Revision classes',
    description: 'We have so many peer classes by fellow learners that you get so many chances to learn that topic.'
  }
];

export default function CohortsFeatureSection() {
  return (
    <section className="max-w-6xl mx-auto px-4 py-16">
      <h2 className="text-4xl font-bold text-center mb-4">Key Benefits of Cohorts</h2>
      <p className="text-center mb-12">Cohorts are best way to learn because you finish the course in a timely manner</p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {features.map((feature, index) => (
          <div key={index} className="border rounded-xl p-6 shadow-sm">
            <div className="mb-2 bg-gray-200 w-8 h-8 rounded">Icon</div>
            <h3 className="text-orange-600 font-semibold text-lg mb-1">{feature.title}</h3>
            <p className="text-gray-700 text-sm">{feature.description}</p>
          </div>
        ))}
      </div>

      <div className="flex flex-col md:flex-row items-start gap-8 mt-12">
        <div className="border rounded-xl p-6 w-full md:w-1/2 flex items-center justify-center">
          {/* Placeholder for student collage */}
          <div className="bg-gray-100 w-full h-48 flex flex-wrap justify-center items-center gap-2">
            {Array.from({ length: 10 }).map((_, i) => (
              <div key={i} className="w-10 h-10 rounded-full bg-gray-300"></div>
            ))}
          </div>
        </div>
        <div className="border rounded-xl p-6 w-full md:w-1/2">
          <h3 className="text-orange-600 font-semibold text-lg mb-1">Alumni Network and job listings</h3>
          <p className="text-gray-700 text-sm">
            The alumni Network that you always wished for in your college. We have a dedicated platform where students get to know each other, do projects, make agencies and join Hackathons. Our HR team also post regular job updates that you can apply directly whenever you are ready.
          </p>
        </div>
      </div>
    </section>
  );
} 
