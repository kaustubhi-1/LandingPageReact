import React from 'react';

const tags = [
  'Community', 'Collaborate', 'Assignments'
];

export default function FreeAPIPage() {
  return (
    <div className="w-full font-sans text-white bg-black">
      {/* Open Source Project Section */}
      <section className="py-12 px-6 text-center bg-white text-black">
        <h1 className="text-3xl font-bold">FreeAPI - Open Source</h1>
        <p className="mt-4 max-w-xl mx-auto">
          Unlock Your Potential with Our API Hub<br/>
          Our API Hub is designed to streamline your learning experience and integrate across multiple platforms.<br/>
          Showcase your true potential in both web and mobile applications.
        </p>

        {/* App Download Section */}
        <div className="flex flex-col md:flex-row items-center justify-center gap-6 mt-6">
          <a
            href="#"
            className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded shadow"
          >
            Download Android App
          </a>
          <a
            href="#"
            className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded shadow"
          >
            Download iOS App
          </a>
        </div>

        {/* YouTube Video Placeholder */}
        <div className="mt-6 border border-gray-400 p-4 w-full md:w-1/2 mx-auto">
          <p>FreeAPI Youtube Video</p>
        </div>

        <button className="mt-4 px-6 py-2 bg-yellow-500 text-white rounded-md shadow hover:bg-yellow-600">
          Check FreeAPI Docs
        </button>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gradient-to-r from-black to-gray-900">
        <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-10 text-white">
          <div className="bg-gray-800 p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-2">Community</h2>
            <p>Join a thriving community of learners and mentors to enhance your skills through collaboration and shared insights.</p>
          </div>
          <div className="bg-gray-800 p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-2">Collaborate</h2>
            <p>Work with peers in real time, solve challenges together, and improve your problem-solving skills.</p>
          </div>
          <div className="md:col-span-2 bg-gray-800 p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-2">Assignments</h2>
            <p>Take on challenging assignments designed to test your knowledge and improve your coding expertise.</p>
          </div>
        </div>
      </section>

      {/* Footer Section */}
      <footer className="bg-black text-white py-10 px-6 text-sm">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-2">ChaiCode</h3>
            <p>Home for Programmers</p>
            <div className="flex space-x-3 mt-4">
              <a href="#">YouTube</a>
              <a href="#">Twitter</a>
              <a href="#">GitHub</a>
            </div>
          </div>
          <div className="flex flex-col gap-1">
            <a href="#">Courses</a>
            <a href="#">Cohort</a>
            <a href="#">Coding Hubs</a>
            <a href="#">FreeAPI</a>
            <a href="#">Vision</a>
          </div>
          <div className="flex flex-col gap-1">
            <a href="#">Docs</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
            <a href="#">Pricing Policy</a>
            <a href="#">Refund Policy</a>
          </div>
        </div>
        <div className="mt-10 text-center text-3xl text-blue-600 font-bold tracking-wide">
          CHAIAURCODE
        </div>
      </footer>
    </div>
  );
}
