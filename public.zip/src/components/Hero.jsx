const HeroSection = () => {
    return (
      <section className="mt-20 md:mt-28 px-4 md:px-8 text-center max-w-3xl mx-auto">
        <p className="text-xs px-3 py-1 inline-block border border-gray-300 dark:border-gray-600 rounded-full mb-4 text-gray-600 dark:text-gray-400">
          Trusted by 1.5M Code Learners
        </p>
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-3">
          Consistency and Community
        </h1>
        <h2 className="text-lg md:text-xl font-semibold text-gray-700 dark:text-gray-300 mb-4">
          An unmatched Learning Experience for coding courses.
        </h2>
        <p className="text-gray-600 dark:text-gray-400 leading-relaxed mb-6">
          Content is everywhere, we provide a learning experience that is unmatched. 
          Bounties, peer learning, peer code reviews, Virtual hostel, Alumni Network, 
          Doubt sessions, Group projects and so many other activities to keep you on track.
        </p>
  
        <a
          href="#cohorts"
          className="inline-flex items-center gap-2 px-5 py-2 border border-yellow-500 text-black dark:text-white rounded-md hover:bg-yellow-100 dark:hover:bg-yellow-900 transition"
        >
          Check all Live Cohorts
          <span className="w-2 h-2 bg-red-600 rounded-full animate-pulse"></span>
        </a>
  
        <div className="mt-10">
          <div className="aspect-video w-full max-w-xl mx-auto border rounded-md border-gray-300 dark:border-gray-600">
            <p className="text-gray-500 dark:text-gray-400 pt-20">Video embed</p>
          </div>
        </div>
      </section>
    );
  };
  
  export default HeroSection;
  