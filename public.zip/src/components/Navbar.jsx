import { useEffect, useState } from 'react';

const Navbar = () => {
  const [theme, setTheme] = useState('light');

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const defaultTheme = savedTheme || (prefersDark ? 'dark' : 'light');
    setTheme(defaultTheme);
    document.documentElement.classList.toggle('dark', defaultTheme === 'dark');
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
    localStorage.setItem('theme', newTheme);
  };

  return (
    <header className="w-full px-4 md:px-8 py-4 border-b dark:border-gray-700 bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="text-xl font-semibold text-gray-900 dark:text-white">ChaiCode</div>
        <nav className="hidden md:flex space-x-6 text-sm font-medium text-gray-700 dark:text-gray-300">
          <a href="#cohorts" className="flex items-center gap-1 hover:text-indigo-500">
            Cohorts <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse"></span>
          </a>
          <a href="#udemy" className="hover:text-indigo-500">Udemy</a>
          <a href="#docs" className="hover:text-indigo-500">Docs</a>
          <a href="#reviews" className="hover:text-indigo-500">Reviews</a>
        </nav>
        <div className="flex items-center space-x-4">
          <button
            onClick={toggleTheme}
            className="w-9 h-9 flex items-center justify-center rounded-full border border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"
            aria-label="Toggle dark mode"
          >
            {theme === 'light' ? '🌙' : '☀️'}
          </button>
          <button className="border px-4 py-1 rounded-md text-sm font-medium hover:bg-gray-100 dark:hover:bg-gray-700 transition">
            Login
          </button>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
