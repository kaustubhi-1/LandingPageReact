import React from 'react';

const testimonials = [
  {
    name: "Student 1",
    feedback: "The course was amazing. Learned more in 4 weeks than 4 months of YouTube!",
  },
  {
    name: "Student 2",
    feedback: "Peer reviews and live sessions helped me stay consistent and improve.",
  },
  {
    name: "Student 3",
    feedback: "The bounties kept me motivated throughout. Highly recommend it!",
  },
  {
    name: "Student 4",
    feedback: "I landed a freelance gig after this cohort. Great content + community.",
  },
  {
    name: "Student 5",
    feedback: "The alumni network is gold! Got a referral through it.",
  },
  {
    name: "Student 6",
    feedback: "Clear, structured, and very hands-on. Love the ChaiCode energy!",
  },
];

const Testimonials = () => {
  return (
    <section className="py-20 bg-white dark:bg-darkBg" id="testimonials">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <span className="text-xs font-mono uppercase tracking-wide text-gray-500 dark:text-gray-400">
          Testimonials
        </span>
        <h2 className="text-4xl font-bold mt-2 text-gray-900 dark:text-white">
          Our Students Feedback
        </h2>
        <p className="text-sm mt-2 text-gray-600 dark:text-gray-300 max-w-xl mx-auto">
          Explore the incredible advantages of enrolling in our courses and enhancing your skills.
        </p>

        {/* Grid of testimonial cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
          {testimonials.map((item, index) => (
            <div
              key={index}
              className="bg-white dark:bg-gray-900 p-6 rounded-md border border-gray-200 dark:border-gray-700 shadow-md min-h-[250px] flex flex-col justify-between"
            >
              <p className="text-gray-700 dark:text-gray-200 text-base leading-relaxed mb-6">
                "{item.feedback}"
              </p>
              <h4 className="text-gray-900 dark:text-white font-semibold text-sm">
                — {item.name}
              </h4>
            </div>
          ))}
        </div>

        {/* CTA Button */}
        <div className="mt-12">
          <button className="bg-white border border-amber-500 text-amber-600 font-medium px-6 py-2 rounded hover:bg-amber-50 transition">
            Join Cohorts Live Classes
          </button>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
