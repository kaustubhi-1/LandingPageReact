import React from 'react';

const tags = [
  'Docker', 'MCP Server', 'Kubernetes', 'Python', 'React Native',
  'Django', 'NextJS', 'GraphQL', 'MongoDB', 'TypeScript',
  'HTML', 'CSS', 'JavaScript', 'Redux', 'Flutter',
  'Node.js', 'Tailwind CSS', 'Firebase', 'Git & GitHub'
];

const CommunitySection = () => {
  return (
    <div className="w-full px-4 py-10 max-w-6xl mx-auto space-y-10">
      
      {/* Topics Cloud Section */}
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold">Topics Cloud</h2>
        <p className="text-gray-600">You can find videos and courses on topics and much more</p>

        <div className="flex flex-wrap justify-center gap-3 mt-6">
          {tags.map((tag, index) => (
            <a
              key={index}
              href={`https://www.youtube.com/results?search_query=${encodeURIComponent(tag)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block border border-gray-300 px-4 py-2 rounded-md text-sm hover:bg-gray-100 transition"
            >
              {tag}
            </a>
          ))}
        </div>
      </div>

      <hr className="border-t border-gray-200" />

      {/* Community Section */}
      <div className="flex flex-col items-center justify-center space-y-6">
        <div className="flex flex-col md:flex-row items-center justify-center gap-10">
          
          {/* Left Text */}
          <div className="text-center md:text-left max-w-md space-y-3">
            <span className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">Community</span>
            <h3 className="text-3xl font-bold leading-snug">
              Join our <br />
              community where <br />
              creativity thrives.
            </h3>
          </div>

          {/* Right Image */}
          <div className="border border-gray-300 rounded-md p-4">
            <img 
              src="https://via.placeholder.com/250x150.png?text=Discord+Image"
              alt="Discord Community"
              className="rounded-md"
            />
          </div>
        </div>

        {/* Centered Button */}
        <button className="bg-yellow-600 text-white px-6 py-3 rounded-md font-semibold shadow-md">
          80,000 Active coders in Discord
        </button>
      </div>
    </div>
  );
};

export default CommunitySection;
