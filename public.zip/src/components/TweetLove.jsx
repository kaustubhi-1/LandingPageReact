const TweetLove = () => {
    return (
      <section className="py-20 bg-white dark:bg-darkBg text-center">
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
          Love that we get from our community
        </p>
        <h2 className="text-3xl sm:text-4xl font-bold mb-6 text-gray-900 dark:text-white">
          Tweet Love
        </h2>
  
        {/* Tweet Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto px-4">
          {[1, 2, 3].map((item) => (
            <div
              key={item}
              className="border rounded-lg p-4 h-40 bg-gray-50 dark:bg-gray-800 text-left shadow-sm"
            >
              <p className="text-sm text-gray-700 dark:text-gray-300">
                Twitter cards with course reviews
              </p>
            </div>
          ))}
        </div>
  
        {/* CTA */}
        <button className="mt-8 inline-flex items-center border border-amber-400 px-6 py-2 rounded-md text-lg font-medium text-gray-900 dark:text-white hover:bg-amber-100 dark:hover:bg-amber-600 transition">
          Join Cohorts Live Classes
        </button>
      </section>
    );
  };
  
  export default TweetLove;
  