import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

const udemyCourses = [
  { id: 1, title: 'Complete web development course', rating: '4.7 Stars' },
  { id: 2, title: 'Full Stack Bootcamp', rating: '4.6 Stars' },
  { id: 3, title: 'JavaScript Mastery', rating: '4.8 Stars' },
  { id: 4, title: 'React + Tailwind Guide', rating: '4.9 Stars' },
  { id: 5, title: 'Backend with Node & MongoDB', rating: '4.7 Stars' },
  { id: 6, title: 'Frontend with React & Vite', rating: '4.6 Stars' },
];

const UdemySection = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 800,
    slidesToShow: 3,
    slidesToScroll: 1,
    arrows: true,
    autoplay: true, // 🔥 Autoplay Enabled
    autoplaySpeed: 3000, // 3 seconds
    responsive: [
      {
        breakpoint: 1024,
        settings: { slidesToShow: 2 },
      },
      {
        breakpoint: 640,
        settings: { slidesToShow: 1 },
      },
    ],
  };

  return (
    <section className="py-16 px-4 max-w-7xl mx-auto">
      <h2 className="text-3xl font-bold text-center mb-6">Udemy</h2>
      <Slider {...settings}>
        {udemyCourses.map((course) => (
          <div key={course.id} className="px-2">
            <div className="bg-white border rounded-lg p-6 shadow text-center space-y-4">
              <h3 className="font-semibold">{course.title}</h3>
              <div className="bg-gray-200 h-40 rounded flex items-center justify-center text-gray-500">Course Preview</div>
              <p className="text-lg font-bold">{course.rating}</p>
              <button className="bg-purple-600 text-white py-1 px-4 rounded">Buy Now</button>
            </div>
          </div>
        ))}
      </Slider>
    </section>
  );
};

export default UdemySection;
